-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: proyecto1
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `averias`
--

DROP TABLE IF EXISTS `averias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `averias` (
  `Num_Averia` int NOT NULL AUTO_INCREMENT,
  `Nivel_Incidencia` varchar(100) NOT NULL,
  `FKcodigo_Postal` int DEFAULT NULL,
  `Direccion` varchar(150) NOT NULL,
  `Descripcion` varchar(150) NOT NULL,
  `Imagen_Averia` blob NOT NULL,
  `FKid_Institucion` int DEFAULT NULL,
  `Fecha_Registro` datetime NOT NULL,
  `Fecha_Completado` datetime NOT NULL,
  `FKid_estado` int DEFAULT NULL,
  `Solucion` varchar(150) NOT NULL,
  `Num_Empleados` int NOT NULL,
  `Costo_Aprox` float NOT NULL,
  `Validador` varchar(100) NOT NULL,
  `Imagen_Completado` blob NOT NULL,
  `FKid_Usuario` int DEFAULT NULL,
  PRIMARY KEY (`Num_Averia`),
  KEY `FKcodigo_Postal` (`FKcodigo_Postal`),
  KEY `FKid_Institucion` (`FKid_Institucion`),
  KEY `FKid_estado` (`FKid_estado`),
  KEY `FKid_Usuario` (`FKid_Usuario`),
  CONSTRAINT `averias_ibfk_1` FOREIGN KEY (`FKcodigo_Postal`) REFERENCES `ubicacion` (`Codigo_Postal`) ON DELETE SET NULL,
  CONSTRAINT `averias_ibfk_2` FOREIGN KEY (`FKid_Institucion`) REFERENCES `instituciones` (`Id_Institucion`) ON DELETE SET NULL,
  CONSTRAINT `averias_ibfk_3` FOREIGN KEY (`FKid_estado`) REFERENCES `estado_averias` (`Id_Estado`) ON DELETE SET NULL,
  CONSTRAINT `averias_ibfk_4` FOREIGN KEY (`FKid_Usuario`) REFERENCES `usuarios` (`Cedula`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `averias`
--

LOCK TABLES `averias` WRITE;
/*!40000 ALTER TABLE `averias` DISABLE KEYS */;
/*!40000 ALTER TABLE `averias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estado_averias`
--

DROP TABLE IF EXISTS `estado_averias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estado_averias` (
  `Id_Estado` int NOT NULL AUTO_INCREMENT,
  `Estado_Averia` varchar(100) NOT NULL,
  PRIMARY KEY (`Id_Estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado_averias`
--

LOCK TABLES `estado_averias` WRITE;
/*!40000 ALTER TABLE `estado_averias` DISABLE KEYS */;
/*!40000 ALTER TABLE `estado_averias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instituciones`
--

DROP TABLE IF EXISTS `instituciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `instituciones` (
  `Id_Institucion` int NOT NULL AUTO_INCREMENT,
  `Nombre_Institucion` varchar(100) NOT NULL,
  `Correo` varchar(50) NOT NULL,
  `Razon_Social` varchar(50) NOT NULL,
  `Pass_Insti` varchar(50) NOT NULL,
  `Reporteador` tinyint(1) NOT NULL,
  `Habilitado` tinyint(1) NOT NULL,
  `FKid_Rol` int DEFAULT NULL,
  PRIMARY KEY (`Id_Institucion`),
  KEY `FKid_Rol` (`FKid_Rol`),
  CONSTRAINT `instituciones_ibfk_1` FOREIGN KEY (`FKid_Rol`) REFERENCES `roles` (`Id_Rol`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instituciones`
--

LOCK TABLES `instituciones` WRITE;
/*!40000 ALTER TABLE `instituciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `instituciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `Id_Rol` int NOT NULL AUTO_INCREMENT,
  `Rol` varchar(50) NOT NULL,
  PRIMARY KEY (`Id_Rol`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ubicacion`
--

DROP TABLE IF EXISTS `ubicacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ubicacion` (
  `Codigo_Postal` int NOT NULL,
  `Provincia` varchar(100) NOT NULL,
  `Canton` varchar(100) NOT NULL,
  `Distrito` varchar(100) NOT NULL,
  PRIMARY KEY (`Codigo_Postal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ubicacion`
--

LOCK TABLES `ubicacion` WRITE;
/*!40000 ALTER TABLE `ubicacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `ubicacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `Cedula` int NOT NULL,
  `Pass_Usuario` varchar(50) NOT NULL,
  `Correo` varchar(50) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Apellido1` varchar(50) NOT NULL,
  `Apellido2` varchar(50) NOT NULL,
  `Habilitado` tinyint(1) NOT NULL,
  `FKid_Rol` int DEFAULT NULL,
  PRIMARY KEY (`Cedula`),
  KEY `FKid_Rol` (`FKid_Rol`),
  CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`FKid_Rol`) REFERENCES `roles` (`Id_Rol`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-15 14:58:46
